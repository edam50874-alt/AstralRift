package com.discord.astralrift.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

/** Veraxis the Star Eater - a multi-phase boss that summons attacks and changes form. */
public class VeraxisTheStar extends Monster {
    private int phase = 1;
    private int attackTick = 0;

    public VeraxisTheStar(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.setMaxUpStep(1.0f);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new MeleeAttackGoal(this, 1.2, true));
        this.goalSelector.addGoal(1, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(2, new RandomLookAroundGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        
        if (this.level() instanceof ServerLevel sl && this.tickCount % 20 == 0) {
            // Phase detection
            if (this.getHealth() < this.getMaxHealth() * 0.66) phase = 2;
            if (this.getHealth() < this.getMaxHealth() * 0.33) phase = 3;
            
            // Summon particle aura
            double r = Math.sin(tickCount * 0.05) * 3 + 5;
            for (int i = 0; i < 8; i++) {
                double angle = (Math.PI * 2 / 8) * i;
                double x = this.getX() + Math.cos(angle) * r;
                double z = this.getZ() + Math.sin(angle) * r;
                sl.sendParticles(ParticleTypes.SOUL, x, this.getY() + 2, z, 1, 0.1, 0.1, 0.1, 0.05);
            }
            
            // Phase 2+: attack patterns
            if (phase >= 2) {
                var players = this.level().getEntitiesOfClass(net.minecraft.world.entity.player.Player.class,
                        this.getBoundingBox().inflate(20));
                for (var p : players) {
                    if (++attackTick % 60 == 0) {
                        // Spike attack
                        sl.sendParticles(ParticleTypes.FLAME, p.getX(), p.getY() + 1, p.getZ(), 10, 1, 1, 1, 0.1);
                        p.hurt(this.level().damageSources().mobAttack(this), 8f);
                    }
                }
            }
        }
    }

    @Override public float getMaxHealth() { return 80f; }
    @Override protected float getStandingEyeHeight(net.minecraft.world.entity.Pose pose, net.minecraft.world.entity.EntityDimensions dims) { return 2.4f; }
    @Override protected net.minecraft.world.entity.ai.navigation.PathNavigation createNavigation(Level level) {
        return new net.minecraft.world.entity.ai.navigation.GroundPathNavigation(this, level);
    }
}
