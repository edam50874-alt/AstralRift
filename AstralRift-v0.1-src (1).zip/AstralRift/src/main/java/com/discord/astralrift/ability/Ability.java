package com.discord.astralrift.ability;

public enum Ability {
    ASTRAL_PROJECTION("astral_projection", "Astral Projection"), // Star
    MANA_SURGE("mana_surge", "Mana Surge"),                      // Circle
    EMBER_WARD("ember_ward", "Ember Ward"),                      // Triangle
    IRON_BASTION("iron_bastion", "Iron Bastion");                // Square

    public final String id;
    public final String display;
    Ability(String id, String display) { this.id = id; this.display = display; }

    public static Ability byId(String id) {
        for (Ability a : values()) if (a.id.equals(id)) return a;
        return null;
    }
}
