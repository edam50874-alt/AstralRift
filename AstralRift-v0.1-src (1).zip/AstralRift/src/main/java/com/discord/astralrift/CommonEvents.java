package com.discord.astralrift;

import com.discord.astralrift.ability.Ability;
import com.discord.astralrift.ability.AstralProjection;
import com.discord.astralrift.data.AstralData;
import com.discord.astralrift.network.ModNetwork;
import com.discord.astralrift.network.OpenCanvasPacket;
import com.discord.astralrift.network.SyncManaPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber(modid = AstralRift.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class CommonEvents {
    private CommonEvents() {}

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        if (AstralData.root(p).getInt("projTicks") > 0) AstralProjection.end(p); // logged out mid-projection
        sync(p);
        if (AstralData.canvasAvailable(p)) {
            ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new OpenCanvasPacket(""));
        }
    }

    /** Death before drawing = canvas gone forever. Already-earned powers stay. */
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) AstralData.lockCanvas(p);
    }

    /** Belt and braces: copy persisted data to the respawned player. */
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        var src = e.getOriginal().getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        e.getEntity().getPersistentData().put(Player.PERSISTED_NBT_TAG, src.copy());
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) sync(p);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;

        // Hunger removed: food pinned full, no exhaustion, no starving.
        p.getFoodData().setFoodLevel(20);
        p.getFoodData().setSaturation(0f);
        p.getFoodData().setExhaustion(0f);

        // Mana regen (2/sec)
        AstralData.setMana(p, AstralData.mana(p) + 0.1f);
        AstralProjection.tick(p);

        // Passive drawn powers
        if (p.tickCount % 100 == 0) {
            if (AstralData.has(p, Ability.EMBER_WARD))
                p.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 220, 0, true, false, true));
            if (AstralData.has(p, Ability.IRON_BASTION))
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 220, 0, true, false, true));
        }
        if (p.tickCount % 10 == 0) sync(p);
    }

    /** Ember Ward: melee attackers catch fire. */
    @SubscribeEvent
    public static void onAttacked(LivingAttackEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && AstralData.has(p, Ability.EMBER_WARD)
                && e.getSource().getEntity() instanceof net.minecraft.world.entity.LivingEntity attacker
                && attacker.distanceTo(p) < 4) {
            attacker.setSecondsOnFire(3);
        }
    }

    public static void sync(ServerPlayer p) {
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                new SyncManaPacket(AstralData.mana(p), AstralData.maxMana(p)));
    }
}
