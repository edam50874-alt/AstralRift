# Astral Rift: Vertical Slice v0.1 (Forge 1.20.1 + GeckoLib 4)

## What's in here
- **The Canvas**: full-screen UI on first join. HOLD SHIFT + drag to draw (clicks alone do nothing). ENTER seals it, BACKSPACE clears, ESC is disabled.
  - Star (pentagram) = Astral Projection (press R: spirit mode 10s, 40 mana, press R again to return)
  - Circle = Mana Surge (+50 max mana) | Triangle = Ember Ward | Square = Iron Bastion
  - Shapes are checked on the server. Gibberish gets rejected and you can try again.
  - Die before drawing and the canvas is locked forever. Powers you earned stay after death.
- **Hunger removed**: the food bar is hidden, hunger stays full, no starving.
- **Mana**: 100 base, regen 2/sec, synced HUD bar where the food bar used to be.
- **Rift Blade** (GeckoLib model + idle/blink anims): right-click a target within 16 blocks to Blink Strike behind it. 14 dmg, 20 mana, 2s cooldown, portal trail.

## Build
1. Install JDK 17.
2. Copy `gradlew`, `gradlew.bat` and `gradle/` from the Forge 1.20.1 MDK (47.3.x) into this folder (or run `gradle wrapper --gradle-version 8.1.1`).
3. `./gradlew build` → `build/libs/astralrift-0.1.0.jar`
4. Drop the jar plus `geckolib-forge-1.20.1-4.4.9.jar` into `mods/`.

## PojavLauncher (mobile)
Forge 1.20.1 runs on Java 17. Map a virtual button to Shift (hold it) and drag your finger to draw. Map R for Astral Projection.

## Next milestones
Stats/Ability/Shop menu → remaining 8 weapons → mob framework (1 mob) → boss framework (Veraxis) → quest engine → Rift Compass + dimension.

## No PC? Build the jar on GitHub (free)
1. Make a new GitHub repo and upload everything in this folder (including `.github/`).
2. Open the **Actions** tab. The "Build mod jar" workflow runs on its own (or hit "Run workflow").
3. When it goes green, download **AstralRift-jar** from the run page. That's your `.jar`.
