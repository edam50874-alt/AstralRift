# Astral Rift: Complete Combat Mod (Forge 1.20.1 + GeckoLib)

## v0.3 - Full System Release

### The Canvas (One-Time Setup)
- Full-screen UI on first join. Hold Shift and drag to draw. No clicks.
- Draw a shape to unlock abilities + passive powers (one chance per player lifetime)
- Die before drawing = canvas locked forever, but powers persist

### 8 Weapons with Unique VFX
1. **Rift Blade** – Teleport behind target, spectral trail (20 mana, 2s cooldown)
2. **Oblivion** – Dark cone blast, sonic boom (35 mana, 3s cooldown)
3. **Star-Drawn Bow** – Comet + 5 homing shards (25 mana, 2.5s cooldown)
4. **Gravity Mall** – Ground slam, launch mobs (30 mana, 3.5s cooldown)
5. **Phase Scythe** – Spectral scythe pulls enemies (22 mana, 2.75s cooldown)
6. **Oculus Staff** – Burning beam (28 mana, 2.25s cooldown)
7. **Void Steel Greatsword** – Scales damage by enemy missing mana (32 mana, 4s cooldown)
8. **Astral Scepter** – 3 mini black holes that pull + damage (38 mana, 4.5s cooldown)

### 8 Abilities (Draw Shapes on Canvas)
- **Astral Projection** (star) – Spirit form 10s, teleport back
- **Mana Surge** (circle) – +50 max mana, grants regeneration
- **Ember Ward** (triangle) – Fire resistance, attackers catch fire
- **Iron Bastion** (square) – Damage resistance
- **Void Strike** (zigzag) – Speed II boost
- **Eclipse Wave** (crescent) – Unlocks Oblivion weapon
- **Gravity Well** (spiral) – Slow falling
- **Mana Echo** (wave) – Regeneration passively

### Mana System
- Base 100 mana, regenerates 2/sec
- Abilities and weapons scale with mana
- Hunger bar removed, stamina is pure focus on mana

### Custom Menu (Press M)
- Stats screen (health, mana, armor)
- Abilities tab (see unlocked powers)
- Shop tab (buy consumables with coins)

### 3 Custom Mobs
- **Void Stalker** (25 HP) – Fast melee, spawns in Overworld
- **Hoarder Goblin** (18 HP) – Quick attacks, small group behavior
- **Shardback** (30 HP) – Tank-like, high armor

### 1 Multi-Phase Boss
- **Veraxis the Star Eater** (80 HP)
  - Phase 1: Basic melee + soul particle aura
  - Phase 2 (66%): Summons spike attacks
  - Phase 3 (33%): Increased aggression

### Quest Framework
3 starter quests:
- Slay 3 Void Stalkers (50 coins reward)
- Master the Canvas (100 coins)
- Face Veraxis (200 coins)

## How to Build
1. Make a GitHub repo, upload the zip via **Add file → Upload files**
2. Open the **Actions** tab, wait for build to complete (5 mins)
3. Download **AstralRift-jar** from artifacts
4. Extract the jar, put in PojavLauncher's `mods/` folder
5. Also download **GeckoLib** 4.4.9 for Forge 1.20.1 into `mods/`

## Controls
- **Shift + Drag** – Draw on canvas (first join only)
- **M** – Open custom menu
- **R** – Use Astral Projection (if unlocked)
- **Right-click** – Use equipped weapon

## Known Limitations
- Mobs don't use custom models yet (GeckoLib animation pending)
- Boss doesn't have full arena mechanics
- Quests track internally but aren't fully integrated to UI
- Shop menu is template only (needs command system)

Next: full GeckoLib models for mobs, full boss arena, quest UI integration
