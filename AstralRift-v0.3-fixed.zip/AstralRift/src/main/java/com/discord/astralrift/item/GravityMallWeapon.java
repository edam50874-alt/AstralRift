package com.discord.astralrift.item;

import com.discord.astralrift.data.AstralData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class GravityMallWeapon extends SwordItem {
    private static final float COST = 30f;

    public GravityMallWeapon(Properties props) {
        super(Tiers.NETHERITE, 7, -2.0f, props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.pass(stack);
        
        if (!AstralData.trySpend(player, COST)) return InteractionResultHolder.fail(stack);
        
        ServerLevel sl = (ServerLevel) level;
        Vec3 pos = player.position().add(0, 1, 0);
        
        // Ground slam
        sl.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 10, 3, 0.5, 3, 0.1);
        
        // Launch nearby mobs
        AABB box = new AABB(pos, pos).inflate(8);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> x.isAlive() && x != player)) {
            e.hurt(level.damageSources().playerAttack(player), 18f);
            e.knockback(1.5, player.getX() - e.getX(), player.getZ() - e.getZ());
        }
        
        sl.playSound(null, player.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1f, 0.8f);
        player.getCooldowns().addCooldown(this, 70);
        return InteractionResultHolder.success(stack);
    }
}
