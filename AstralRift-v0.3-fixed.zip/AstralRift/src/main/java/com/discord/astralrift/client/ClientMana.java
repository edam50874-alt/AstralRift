package com.discord.astralrift.client;

public final class ClientMana {
    public static float mana = 100f;
    public static float max = 100f;
    private ClientMana() {}
}
