package com.discord.astralrift.network;

import com.discord.astralrift.client.ClientMana;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record SyncManaPacket(float mana, float max) {
    public static void encode(SyncManaPacket m, FriendlyByteBuf b) { b.writeFloat(m.mana); b.writeFloat(m.max); }
    public static SyncManaPacket decode(FriendlyByteBuf b) { return new SyncManaPacket(b.readFloat(), b.readFloat()); }
    public static void handle(SyncManaPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> { ClientMana.mana = m.mana; ClientMana.max = m.max; });
        ctx.get().setPacketHandled(true);
    }
}
