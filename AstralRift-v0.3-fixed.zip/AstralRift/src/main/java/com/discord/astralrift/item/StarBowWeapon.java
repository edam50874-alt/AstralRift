package com.discord.astralrift.item;

import com.discord.astralrift.data.AstralData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/** Star-Drawn Bow: fires a comet that splits into 5 homing shards. */
public class StarBowWeapon extends SwordItem {
    private static final float COST = 25f;

    public StarBowWeapon(Properties props) {
        super(Tiers.NETHERITE, 5, -2.3f, props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.pass(stack);
        
        if (!AstralData.trySpend(player, COST)) return InteractionResultHolder.fail(stack);
        
        ServerLevel sl = (ServerLevel) level;
        Vec3 eye = player.getEyePosition();
        Vec3 dir = player.getLookAngle();
        Vec3 cometPos = eye.add(dir.scale(3));
        
        // Comet trail
        for (int i = 0; i < 20; i++) {
            Vec3 p = cometPos.add(dir.scale(i * 0.5));
            sl.sendParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 2, 0.1, 0.1, 0.1, 0.1);
        }
        
        // Find target
        Vec3 end = eye.add(dir.scale(30));
        AABB box = player.getBoundingBox().expandTowards(dir.scale(30)).inflate(1.5);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(level, player, eye, end, box,
                e -> e instanceof LivingEntity && e.isAlive() && e != player);
        
        if (hit != null) {
            LivingEntity target = (LivingEntity) hit.getEntity();
            target.hurt(level.damageSources().playerAttack(player), 8f);
            
            // 5 homing shards
            for (int i = 0; i < 5; i++) {
                double angle = (Math.PI * 2 / 5) * i;
                Vec3 shardDir = new Vec3(Math.cos(angle), -0.3, Math.sin(angle)).normalize();
                Vec3 shardPos = target.position().add(shardDir.scale(3));
                sl.sendParticles(ParticleTypes.END_ROD, shardPos.x, shardPos.y, shardPos.z, 3, 0.2, 0.2, 0.2, 0.1);
                
                // Shard does small damage on impact
                AABB shardBox = new AABB(shardPos, shardPos).inflate(1.5);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, shardBox, x -> x.isAlive())) {
                    if (e != player && e != target) e.hurt(level.damageSources().playerAttack(player), 3f);
                }
            }
        }
        
        sl.playSound(null, player.blockPosition(), SoundEvents.ARROW_SHOOT, SoundSource.PLAYERS, 1f, 1.2f);
        player.getCooldowns().addCooldown(this, 50);
        return InteractionResultHolder.success(stack);
    }
}
