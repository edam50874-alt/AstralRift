package com.discord.astralrift.ability;

public enum Ability {
    ASTRAL_PROJECTION("astral_projection", "Astral Projection", "star"),
    MANA_SURGE("mana_surge", "Mana Surge", "circle"),
    EMBER_WARD("ember_ward", "Ember Ward", "triangle"),
    IRON_BASTION("iron_bastion", "Iron Bastion", "square"),
    VOID_STRIKE("void_strike", "Void Strike", "zigzag"),      // NEW
    ECLIPSE_WAVE("eclipse_wave", "Eclipse Wave", "crescent"),  // NEW
    GRAVITY_WELL("gravity_well", "Gravity Well", "spiral"),    // NEW
    MANA_ECHO("mana_echo", "Mana Echo", "wave");               // NEW

    public final String id;
    public final String display;
    public final String shape;
    
    Ability(String id, String display, String shape) { 
        this.id = id; 
        this.display = display;
        this.shape = shape;
    }

    public static Ability byId(String id) {
        for (Ability a : values()) if (a.id.equals(id)) return a;
        return null;
    }
}
