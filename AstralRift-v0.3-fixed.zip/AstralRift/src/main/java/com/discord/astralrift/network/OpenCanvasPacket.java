package com.discord.astralrift.network;

import com.discord.astralrift.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record OpenCanvasPacket(String hint) {
    public static void encode(OpenCanvasPacket m, FriendlyByteBuf b) { b.writeUtf(m.hint, 256); }
    public static OpenCanvasPacket decode(FriendlyByteBuf b) { return new OpenCanvasPacket(b.readUtf(256)); }
    public static void handle(OpenCanvasPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openCanvas(m.hint)));
        ctx.get().setPacketHandled(true);
    }
}
