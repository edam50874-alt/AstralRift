package com.discord.astralrift.item;

import com.discord.astralrift.data.AstralData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class AstralScepterWeapon extends SwordItem {
    private static final float COST = 38f;

    public AstralScepterWeapon(Properties props) {
        super(Tiers.NETHERITE, 6, -2.1f, props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.pass(stack);
        
        if (!AstralData.trySpend(player, COST)) return InteractionResultHolder.fail(stack);
        
        ServerLevel sl = (ServerLevel) level;
        Vec3 pos = player.position().add(0, player.getEyeHeight(), 0);
        
        // Mini black holes that pull and damage
        for (int i = 0; i < 3; i++) {
            Vec3 hole = pos.add(player.getLookAngle().scale(3 + i * 3));
            for (int t = 0; t < 20; t++) {
                sl.sendParticles(ParticleTypes.PORTAL, hole.x, hole.y, hole.z, 2, 0.3, 0.3, 0.3, 0.1);
            }
            
            AABB pull = new AABB(hole, hole).inflate(4);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, pull, x -> x.isAlive() && x != player)) {
                e.hurt(level.damageSources().playerAttack(player), 10f);
                Vec3 toward = hole.subtract(e.position()).normalize().scale(1.2);
                e.setDeltaMovement(e.getDeltaMovement().add(toward));
            }
        }
        
        sl.playSound(null, player.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1f, 0.4f);
        player.getCooldowns().addCooldown(this, 90);
        return InteractionResultHolder.success(stack);
    }
}
