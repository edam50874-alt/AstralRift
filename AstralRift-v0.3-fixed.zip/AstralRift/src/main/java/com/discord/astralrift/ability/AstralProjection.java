package com.discord.astralrift.ability;

import com.discord.astralrift.data.AstralData;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.GameType;

/** Leave your body as a spirit for 10s, then snap back to where you stood. */
public final class AstralProjection {
    public static final float COST = 40f;
    public static final int DURATION = 200;

    private AstralProjection() {}

    public static void activate(ServerPlayer p) {
        if (!AstralData.has(p, Ability.ASTRAL_PROJECTION)) { p.displayClientMessage(Component.literal("You never drew the Star."), true); return; }
        CompoundTag d = AstralData.root(p);
        if (d.getInt("projTicks") > 0) { end(p); return; } // press again to return early
        if (!AstralData.trySpend(p, COST)) { p.displayClientMessage(Component.literal("Not enough mana."), true); return; }

        d.putDouble("projX", p.getX()); d.putDouble("projY", p.getY()); d.putDouble("projZ", p.getZ());
        d.putFloat("projYaw", p.getYRot()); d.putFloat("projPitch", p.getXRot());
        d.putString("projDim", p.level().dimension().location().toString());
        d.putInt("projMode", p.gameMode.getGameModeForPlayer().getId());
        d.putInt("projTicks", DURATION);
        p.setGameMode(GameType.SPECTATOR);
        p.level().playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1f, 1.6f);
        p.displayClientMessage(Component.literal("✦ Astral Projection"), true);
    }

    public static void tick(ServerPlayer p) {
        CompoundTag d = AstralData.root(p);
        int t = d.getInt("projTicks");
        if (t <= 0) return;
        if (--t <= 0) end(p); else d.putInt("projTicks", t);
    }

    public static void end(ServerPlayer p) {
        CompoundTag d = AstralData.root(p);
        if (!d.contains("projDim")) { d.putInt("projTicks", 0); return; }
        ResourceKey<net.minecraft.world.level.Level> key = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(d.getString("projDim")));
        ServerLevel lvl = p.server.getLevel(key);
        if (lvl == null) lvl = p.server.overworld();
        p.teleportTo(lvl, d.getDouble("projX"), d.getDouble("projY"), d.getDouble("projZ"), d.getFloat("projYaw"), d.getFloat("projPitch"));
        p.setGameMode(GameType.byId(d.getInt("projMode")));
        d.putInt("projTicks", 0);
        d.remove("projDim");
        p.level().playSound(null, p.blockPosition(), SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1f, 1.6f);
    }
}
