package com.discord.astralrift.client;

import com.discord.astralrift.AstralRift;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = AstralRift.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    public static final KeyMapping ASTRAL_KEY = new KeyMapping("key.astralrift.astral_projection",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.astralrift");

    private ClientModEvents() {}

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) { e.register(ASTRAL_KEY); }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent e) {
        e.registerAbove(VanillaGuiOverlay.HOTBAR.id(), "mana", (gui, g, pt, w, h) -> {
            var mc = net.minecraft.client.Minecraft.getInstance();
            if (mc.options.hideGui || mc.player == null || mc.player.isSpectator() || mc.player.isCreative()) return;
            int x = w / 2 + 10, y = h - 39, bw = 81, bh = 7;
            float frac = ClientMana.max <= 0 ? 0 : ClientMana.mana / ClientMana.max;
            g.fill(x - 1, y - 1, x + bw + 1, y + bh + 1, 0xFF000000);
            g.fill(x, y, x + bw, y + bh, 0xFF1A1033);
            g.fillGradient(x, y, x + (int) (bw * frac), y + bh, 0xFF7FD4FF, 0xFF6A2CFF);
            String txt = (int) ClientMana.mana + "/" + (int) ClientMana.max;
            g.drawString(mc.font, txt, x + bw / 2 - mc.font.width(txt) / 2, y - 9, 0x9FE3FF, true);
        });
    }
}
