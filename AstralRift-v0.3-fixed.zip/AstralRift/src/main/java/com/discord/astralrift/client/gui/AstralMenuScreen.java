package com.discord.astralrift.client.gui;

import com.discord.astralrift.client.ClientMana;
import com.discord.astralrift.data.AstralData;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class AstralMenuScreen extends Screen {
    private Tab active = Tab.STATS;
    private int scroll = 0;

    enum Tab { STATS, ABILITIES, SHOP }

    public AstralMenuScreen() {
        super(Component.literal("✦ Astral Menu ✦"));
    }

    @Override public boolean isPauseScreen() { return true; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(0, 0, width, height, 0xBB070414, 0xBB160A2E);
        
        // Tabs
        drawTab(g, 10, 10, "Stats", Tab.STATS, mx, my);
        drawTab(g, 60, 10, "Abilities", Tab.ABILITIES, mx, my);
        drawTab(g, 140, 10, "Shop", Tab.SHOP, mx, my);
        
        g.fill(10, 32, width - 10, 33, 0xFF7FD4FF);
        
        if (active == Tab.STATS) renderStats(g);
        else if (active == Tab.ABILITIES) renderAbilities(g);
        else if (active == Tab.SHOP) renderShop(g);
        
        super.render(g, mx, my, pt);
    }

    private void drawTab(GuiGraphics g, int x, int y, String name, Tab tab, int mx, int my) {
        boolean hovered = mx >= x && mx < x + 40 && my >= y && my < y + 20;
        int color = active == tab ? 0xFF9FE3FF : (hovered ? 0xFF6A2CFF : 0xFF3D1455);
        g.fill(x, y, x + 40, y + 20, color);
        g.drawCenteredString(font, name, x + 20, y + 6, 0xFFFFFF);
        if (hovered && active != tab) { active = tab; scroll = 0; }
    }

    private void renderStats(GuiGraphics g) {
        var p = minecraft.player;
        int y = 50;
        g.drawString(font, "Health: " + (int) p.getHealth() + "/" + (int) p.getMaxHealth(), 20, y, 0xFF00FF00);
        y += 20;
        g.drawString(font, "Mana: " + (int) ClientMana.mana + "/" + (int) ClientMana.max, 20, y, 0xFF0099FF);
        y += 20;
        g.drawString(font, "Armor: " + p.getArmorValue(), 20, y, 0xFFFFAA00);
    }

    private void renderAbilities(GuiGraphics g) {
        int y = 50;
        for (var a : AstralData.abilities(minecraft.player)) {
            g.drawString(font, "✦ " + a.display, 20, y, 0xFFF0D8FF);
            y += 20;
        }
        if (AstralData.abilities(minecraft.player).isEmpty()) {
            g.drawCenteredString(font, "Draw shapes on the canvas to unlock abilities", width / 2, height / 2, 0xFFAAAAAA);
        }
    }

    private void renderShop(GuiGraphics g) {
        int y = 50;
        g.drawString(font, "Healing Potion - 10 Coins", 20, y, 0xFF00FF00); y += 20;
        g.drawString(font, "Mana Restore - 15 Coins", 20, y, 0xFF0099FF); y += 20;
        g.drawString(font, "Speed Essence - 20 Coins", 20, y, 0xFFFFAA00);
        g.drawCenteredString(font, "(Use /buy <item> to purchase)", width / 2, height - 30, 0xFFAAAAAA);
    }

    @Override public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_M) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
