package com.discord.astralrift.item;

import com.discord.astralrift.data.AstralData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Oblivion: charge dark energy then release an Eclipse Wave to slash all foes in a cone. */
public class OblivionWeapon extends SwordItem {
    private static final float COST = 35f;

    public OblivionWeapon(Properties props) {
        super(Tiers.NETHERITE, 6, -2.1f, props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.pass(stack);
        
        if (!AstralData.trySpend(player, COST)) return InteractionResultHolder.fail(stack);
        
        ServerLevel sl = (ServerLevel) level;
        Vec3 pos = player.position().add(0, player.getEyeHeight(), 0);
        Vec3 dir = player.getLookAngle();
        
        // Dark charge-up particles
        for (int i = 0; i < 8; i++) {
            Vec3 p = pos.add(dir.scale(2 + i * 0.5));
            sl.sendParticles(ParticleTypes.SOUL, p.x, p.y, p.z, 3, 0.2, 0.2, 0.2, 0.05);
        }
        
        // Cone damage
        AABB cone = new AABB(pos, pos).expandTowards(dir.scale(20)).inflate(5);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, cone, x -> x != player && x.isAlive())) {
            if (e.distanceTo(player) <= 20) {
                e.hurt(level.damageSources().playerAttack(player), 16f);
                sl.sendParticles(ParticleTypes.SWEEP_ATTACK, e.getX(), e.getY() + 1, e.getZ(), 5, 0.3, 0.3, 0.3, 0);
            }
        }
        
        sl.playSound(null, player.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1f, 0.7f);
        player.getCooldowns().addCooldown(this, 60);
        return InteractionResultHolder.success(stack);
    }
}
