package com.discord.astralrift.network;

import com.discord.astralrift.CommonEvents;
import com.discord.astralrift.ability.Ability;
import com.discord.astralrift.ability.ShapeRecognizer;
import com.discord.astralrift.data.AstralData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public record SubmitDrawingPacket(List<float[]> points) {
    private static final int MAX = 2048;

    public static void encode(SubmitDrawingPacket m, FriendlyByteBuf b) {
        int n = Math.min(m.points.size(), MAX);
        b.writeVarInt(n);
        for (int i = 0; i < n; i++) { b.writeFloat(m.points.get(i)[0]); b.writeFloat(m.points.get(i)[1]); }
    }

    public static SubmitDrawingPacket decode(FriendlyByteBuf b) {
        int n = Math.min(b.readVarInt(), MAX);
        List<float[]> pts = new ArrayList<>(n);
        for (int i = 0; i < n; i++) pts.add(new float[]{b.readFloat(), b.readFloat()});
        return new SubmitDrawingPacket(pts);
    }

    public static void handle(SubmitDrawingPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer p = ctx.get().getSender();
            if (p == null || !AstralData.canvasAvailable(p)) return; // used or locked: ignore forever
            Ability a = ShapeRecognizer.recognize(m.points);
            if (a == null) {
                ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                        new OpenCanvasPacket("The canvas rejects meaningless marks. Draw a closed shape."));
                return;
            }
            AstralData.grant(p, a);
            AstralData.resolveCanvas(p);
            CommonEvents.sync(p);
            p.level().playSound(null, p.blockPosition(), SoundEvents.END_PORTAL_SPAWN, SoundSource.PLAYERS, 0.7f, 1.4f);
            p.sendSystemMessage(Component.literal("✦ Your drawing awakens: " + a.display).withStyle(ChatFormatting.LIGHT_PURPLE));
        });
        ctx.get().setPacketHandled(true);
    }
}
