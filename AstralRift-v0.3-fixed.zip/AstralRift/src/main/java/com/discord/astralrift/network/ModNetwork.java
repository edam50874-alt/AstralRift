package com.discord.astralrift.network;

import com.discord.astralrift.AstralRift;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(AstralRift.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    private ModNetwork() {}

    public static void register() {
        int id = 0;
        CHANNEL.messageBuilder(OpenCanvasPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenCanvasPacket::encode).decoder(OpenCanvasPacket::decode).consumerMainThread(OpenCanvasPacket::handle).add();
        CHANNEL.messageBuilder(SubmitDrawingPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(SubmitDrawingPacket::encode).decoder(SubmitDrawingPacket::decode).consumerMainThread(SubmitDrawingPacket::handle).add();
        CHANNEL.messageBuilder(SyncManaPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncManaPacket::encode).decoder(SyncManaPacket::decode).consumerMainThread(SyncManaPacket::handle).add();
        CHANNEL.messageBuilder(UseAbilityPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(UseAbilityPacket::encode).decoder(UseAbilityPacket::decode).consumerMainThread(UseAbilityPacket::handle).add();
    }
}
