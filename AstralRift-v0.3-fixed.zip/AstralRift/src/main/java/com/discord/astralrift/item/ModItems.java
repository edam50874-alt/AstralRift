package com.discord.astralrift.item;

import com.discord.astralrift.AstralRift;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, AstralRift.MODID);

    public static final RegistryObject<Item> RIFT_BLADE = ITEMS.register("rift_blade",
            () -> new RiftBladeItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    
    public static final RegistryObject<Item> OBLIVION = ITEMS.register("oblivion",
            () -> new OblivionWeapon(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    
    public static final RegistryObject<Item> STAR_BOW = ITEMS.register("star_bow",
            () -> new StarBowWeapon(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    
    public static final RegistryObject<Item> GRAVITY_MALL = ITEMS.register("gravity_mall",
            () -> new GravityMallWeapon(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    
    public static final RegistryObject<Item> PHASE_SCYTHE = ITEMS.register("phase_scythe",
            () -> new PhaseScytheWeapon(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    
    public static final RegistryObject<Item> OCULUS_STAFF = ITEMS.register("oculus_staff",
            () -> new OculusStaffWeapon(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    
    public static final RegistryObject<Item> VOID_GREATSWORD = ITEMS.register("void_greatsword",
            () -> new VoidGreatswordWeapon(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));
    
    public static final RegistryObject<Item> ASTRAL_SCEPTER = ITEMS.register("astral_scepter",
            () -> new AstralScepterWeapon(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC).fireResistant()));

    private ModItems() {}
}
