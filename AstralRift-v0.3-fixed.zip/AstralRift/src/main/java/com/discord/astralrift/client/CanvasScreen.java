package com.discord.astralrift.client;

import com.discord.astralrift.network.ModNetwork;
import com.discord.astralrift.network.SubmitDrawingPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Full-screen, one-time canvas.
 * Drawing = HOLD SHIFT + move the cursor/finger. Clicks alone never draw.
 * Works on PojavLauncher: touch-drag moves the cursor, Shift is a virtual key.
 * ENTER = seal the drawing, BACKSPACE = clear. ESC is disabled.
 */
public class CanvasScreen extends Screen {
    private final List<List<float[]>> strokes = new ArrayList<>();
    private List<float[]> current;
    private final String hint;

    public CanvasScreen(String hint) {
        super(Component.literal("The Canvas"));
        this.hint = hint;
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean isPauseScreen() { return false; }

    private void trace(double x, double y) {
        if (!hasShiftDown()) { current = null; return; }
        if (current == null) { current = new ArrayList<>(); strokes.add(current); }
        if (!current.isEmpty()) {
            float[] last = current.get(current.size() - 1);
            if (Math.hypot(last[0] - x, last[1] - y) < 2) return;
        }
        current.add(new float[]{(float) x, (float) y});
    }

    @Override public void mouseMoved(double x, double y) { trace(x, y); }

    @Override public boolean mouseDragged(double x, double y, int button, double dx, double dy) { trace(x, y); return true; }

    /** Swallow clicks: left/right click must never draw. */
    @Override public boolean mouseClicked(double x, double y, int button) { return true; }
    @Override public boolean mouseReleased(double x, double y, int button) { return true; }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { submit(); return true; }
        if (key == GLFW.GLFW_KEY_BACKSPACE) { strokes.clear(); current = null; return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean keyReleased(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT || key == GLFW.GLFW_KEY_RIGHT_SHIFT) current = null;
        return super.keyReleased(key, scan, mods);
    }

    private void submit() {
        List<float[]> flat = new ArrayList<>();
        float s = Math.min(width, height);
        for (List<float[]> st : strokes) for (float[] p : st) flat.add(new float[]{p[0] / s, p[1] / s});
        if (flat.size() < 12) return;
        ModNetwork.CHANNEL.sendToServer(new SubmitDrawingPacket(flat));
        onClose();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fillGradient(0, 0, width, height, 0xF0070414, 0xF0160A2E);
        for (List<float[]> st : strokes) {
            for (int i = 1; i < st.size(); i++) line(g, st.get(i - 1), st.get(i));
            if (st.size() == 1) dot(g, st.get(0)[0], st.get(0)[1]);
        }
        g.drawCenteredString(font, "§d✦ THE CANVAS ✦", width / 2, 14, 0xFFFFFF);
        g.drawCenteredString(font, "Hold SHIFT and drag to draw. ENTER to seal fate. BACKSPACE to clear.", width / 2, 28, 0xBBAAEE);
        g.drawCenteredString(font, "§7You get one chance, ever. Die first and it's gone.", width / 2, 40, 0xAAAAAA);
        if (!hint.isEmpty()) g.drawCenteredString(font, "§c" + hint, width / 2, height - 20, 0xFFFFFF);
        if (hasShiftDown()) dot(g, mx, my);
        super.render(g, mx, my, pt);
    }

    private void line(GuiGraphics g, float[] a, float[] b) {
        double d = Math.hypot(b[0] - a[0], b[1] - a[1]);
        int steps = Math.max(1, (int) d);
        for (int i = 0; i <= steps; i++) {
            float t = (float) i / steps;
            dot(g, a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t);
        }
    }

    private void dot(GuiGraphics g, float x, float y) {
        int ix = (int) x, iy = (int) y;
        g.fill(ix - 2, iy - 2, ix + 2, iy + 2, 0x55B266FF);
        g.fill(ix - 1, iy - 1, ix + 1, iy + 1, 0xFFF0D8FF);
    }
}
