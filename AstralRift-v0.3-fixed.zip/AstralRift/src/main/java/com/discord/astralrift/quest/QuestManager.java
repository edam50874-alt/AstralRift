package com.discord.astralrift.quest;

import java.util.HashMap;
import java.util.Map;

public class QuestManager {
    private static final Map<String, Quest> QUESTS = new HashMap<>();

    static {
        QUESTS.put("slay_stalkers", new Quest("slay_stalkers", "Slay 3 Void Stalkers", "Defeat 3 Void Stalkers in the Overworld", 50));
        QUESTS.put("draw_shapes", new Quest("draw_shapes", "Master the Canvas", "Draw 4 different shapes on the canvas", 100));
        QUESTS.put("find_boss", new Quest("find_boss", "Face Veraxis", "Encounter Veraxis the Star Eater", 200));
    }

    public static Quest getQuest(String id) {
        return QUESTS.get(id);
    }

    public static void registerQuest(Quest q) {
        QUESTS.put(q.id, q);
    }
}
