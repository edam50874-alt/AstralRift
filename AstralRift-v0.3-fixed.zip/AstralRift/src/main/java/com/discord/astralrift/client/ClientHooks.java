package com.discord.astralrift.client;

import net.minecraft.client.Minecraft;

public final class ClientHooks {
    private ClientHooks() {}
    public static void openCanvas(String hint) { Minecraft.getInstance().setScreen(new CanvasScreen(hint)); }
}
