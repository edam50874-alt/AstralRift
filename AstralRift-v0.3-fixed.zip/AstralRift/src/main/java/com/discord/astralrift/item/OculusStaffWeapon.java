package com.discord.astralrift.item;

import com.discord.astralrift.data.AstralData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class OculusStaffWeapon extends SwordItem {
    private static final float COST = 28f;

    public OculusStaffWeapon(Properties props) {
        super(Tiers.NETHERITE, 5, -2.3f, props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.pass(stack);
        
        if (!AstralData.trySpend(player, COST)) return InteractionResultHolder.fail(stack);
        
        ServerLevel sl = (ServerLevel) level;
        Vec3 dir = player.getLookAngle();
        Vec3 beam = player.position().add(0, player.getEyeHeight(), 0);
        
        // Continuous beam
        for (int i = 0; i < 25; i++) {
            Vec3 p = beam.add(dir.scale(i * 0.8));
            sl.sendParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 3, 0.2, 0.2, 0.2, 0.1);
            sl.sendParticles(ParticleTypes.SMOKE, p.x, p.y, p.z, 1, 0.1, 0.1, 0.1, 0.05);
            
            AABB hit = new AABB(p, p).inflate(1);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, hit, x -> x.isAlive() && x != player)) {
                e.hurt(level.damageSources().playerAttack(player), 4f);
                e.setSecondsOnFire(2);
            }
        }
        
        sl.playSound(null, player.blockPosition(), SoundEvents.FIRE_AMBIENT, SoundSource.PLAYERS, 1f, 1.2f);
        player.getCooldowns().addCooldown(this, 45);
        return InteractionResultHolder.success(stack);
    }
}
