package com.discord.astralrift.item;

import com.discord.astralrift.client.RiftBladeRenderer;
import com.discord.astralrift.data.AstralData;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.SingletonGeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.function.Consumer;

/** Rift Blade: right-click to Blink Strike behind the targeted foe, leaving a spectral trail. */
public class RiftBladeItem extends SwordItem implements GeoItem {
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop("animation.rift_blade.idle");
    private static final RawAnimation BLINK = RawAnimation.begin().thenPlay("animation.rift_blade.blink");
    private static final float MANA_COST = 20f;
    private static final double RANGE = 16.0;

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public RiftBladeItem(Properties props) {
        super(Tiers.NETHERITE, 5, -2.2f, props);
        SingletonGeoAnimatable.registerSyncedAnimatable(this);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.pass(stack);

        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getLookAngle().scale(RANGE));
        AABB box = player.getBoundingBox().expandTowards(player.getLookAngle().scale(RANGE)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(level, player, eye, end, box,
                e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator() && e != player);
        if (hit == null) { player.displayClientMessage(Component.literal("No target in the rift."), true); return InteractionResultHolder.fail(stack); }
        if (!AstralData.trySpend(player, MANA_COST)) { player.displayClientMessage(Component.literal("Not enough mana."), true); return InteractionResultHolder.fail(stack); }

        Entity target = hit.getEntity();
        ServerLevel sl = (ServerLevel) level;
        Vec3 from = player.position();
        Vec3 facing = Vec3.directionFromRotation(0, target.getYRot());
        Vec3 behind = target.position().subtract(facing.scale(target.getBbWidth() + 1.0));

        // Spectral trail
        int steps = (int) (from.distanceTo(behind) * 3);
        for (int i = 0; i <= steps; i++) {
            Vec3 p = from.lerp(behind, i / (double) Math.max(steps, 1));
            sl.sendParticles(ParticleTypes.REVERSE_PORTAL, p.x, p.y + 1, p.z, 2, 0.1, 0.3, 0.1, 0.01);
            sl.sendParticles(ParticleTypes.END_ROD, p.x, p.y + 1, p.z, 1, 0.05, 0.2, 0.05, 0.0);
        }

        player.teleportTo(behind.x, target.getY(), behind.z);
        player.setYRot(target.getYRot());
        player.setYHeadRot(target.getYRot());
        target.hurt(level.damageSources().playerAttack(player), 14f);
        sl.sendParticles(ParticleTypes.SWEEP_ATTACK, target.getX(), target.getY() + 1, target.getZ(), 3, 0.3, 0.3, 0.3, 0);
        level.playSound(null, player.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1f, 0.6f);

        triggerAnim(player, GeoItem.getOrAssignId(stack, sl), "main", "blink");
        player.getCooldowns().addCooldown(this, 40);
        return InteractionResultHolder.success(stack);
    }

    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            private RiftBladeRenderer renderer;
            @Override public BlockEntityWithoutLevelRenderer getCustomRenderer() {
                if (renderer == null) renderer = new RiftBladeRenderer();
                return renderer;
            }
        });
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "main", 2, state -> state.setAndContinue(IDLE))
                .triggerableAnim("blink", BLINK));
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
