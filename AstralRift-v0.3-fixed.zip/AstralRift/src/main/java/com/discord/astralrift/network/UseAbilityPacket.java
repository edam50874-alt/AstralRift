package com.discord.astralrift.network;

import com.discord.astralrift.ability.Ability;
import com.discord.astralrift.ability.AstralProjection;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public record UseAbilityPacket(String id) {
    public static void encode(UseAbilityPacket m, FriendlyByteBuf b) { b.writeUtf(m.id, 64); }
    public static UseAbilityPacket decode(FriendlyByteBuf b) { return new UseAbilityPacket(b.readUtf(64)); }
    public static void handle(UseAbilityPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer p = ctx.get().getSender();
            if (p == null) return;
            if (Ability.byId(m.id) == Ability.ASTRAL_PROJECTION) AstralProjection.activate(p);
        });
        ctx.get().setPacketHandled(true);
    }
}
