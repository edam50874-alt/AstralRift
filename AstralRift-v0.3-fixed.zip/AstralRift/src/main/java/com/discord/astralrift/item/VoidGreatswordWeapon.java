package com.discord.astralrift.item;

import com.discord.astralrift.data.AstralData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

public class VoidGreatswordWeapon extends SwordItem {
    private static final float COST = 32f;

    public VoidGreatswordWeapon(Properties props) {
        super(Tiers.NETHERITE, 8, -2.0f, props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.pass(stack);
        
        if (!AstralData.trySpend(player, COST)) return InteractionResultHolder.fail(stack);
        
        ServerLevel sl = (ServerLevel) level;
        AABB box = player.getBoundingBox().inflate(6);
        
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> x.isAlive() && x != player)) {
            float manaLeft = Math.max(0, AstralData.mana(e instanceof Player ? (Player) e : null));
            float damage = 10 + (20 - manaLeft) / 4;
            e.hurt(level.damageSources().playerAttack(player), damage);
            sl.sendParticles(ParticleTypes.SOUL, e.getX(), e.getY() + 1, e.getZ(), 5, 0.3, 0.3, 0.3, 0.05);
        }
        
        sl.playSound(null, player.blockPosition(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1f, 0.5f);
        player.getCooldowns().addCooldown(this, 80);
        return InteractionResultHolder.success(stack);
    }
}
