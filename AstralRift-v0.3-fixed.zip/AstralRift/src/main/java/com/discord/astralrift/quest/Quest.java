package com.discord.astralrift.quest;

import net.minecraft.world.entity.player.Player;

public class Quest {
    public String id;
    public String title;
    public String description;
    public int reward;
    public boolean completed;

    public Quest(String id, String title, String desc, int reward) {
        this.id = id;
        this.title = title;
        this.description = desc;
        this.reward = reward;
        this.completed = false;
    }

    public void complete(Player p) {
        if (!completed) {
            completed = true;
            p.displayClientMessage(net.minecraft.network.chat.Component.literal("✦ Quest Complete: " + title), false);
        }
    }
}
