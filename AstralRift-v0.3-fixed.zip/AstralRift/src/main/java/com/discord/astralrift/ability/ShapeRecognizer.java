package com.discord.astralrift.ability;

import java.util.ArrayList;
import java.util.List;

public final class ShapeRecognizer {
    private static final int N = 96;
    private ShapeRecognizer() {}

    public static Ability recognize(List<float[]> raw) {
        if (raw.size() < 12) return null;
        List<float[]> pts = resample(raw, N);
        if (pts.size() < N / 2) return null;

        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (float[] p : pts) { minX = Math.min(minX, p[0]); maxX = Math.max(maxX, p[0]); minY = Math.min(minY, p[1]); maxY = Math.max(maxY, p[1]); }
        double diag = Math.hypot(maxX - minX, maxY - minY);
        if (diag < 0.15) return null;

        float[] first = pts.get(0), last = pts.get(pts.size() - 1);
        if (Math.hypot(first[0] - last[0], first[1] - last[1]) > 0.25 * diag) return null;

        double cx = 0, cy = 0;
        for (float[] p : pts) { cx += p[0]; cy += p[1]; }
        cx /= pts.size(); cy /= pts.size();
        double mean = 0;
        double[] r = new double[pts.size()];
        for (int i = 0; i < pts.size(); i++) { r[i] = Math.hypot(pts.get(i)[0] - cx, pts.get(i)[1] - cy); mean += r[i]; }
        mean /= r.length;
        double var = 0;
        for (double v : r) var += (v - mean) * (v - mean);
        double cv = Math.sqrt(var / r.length) / Math.max(mean, 1e-6);

        int corners = countCorners(pts, 3, Math.toRadians(60));
        double windings = Math.abs(totalTurning(pts)) / (2 * Math.PI);
        double variance = cv;

        // Classifiers
        if (cv < 0.18 && corners <= 1) return Ability.MANA_SURGE;      // Circle
        if (corners == 5 && windings >= 1.6) return Ability.ASTRAL_PROJECTION;  // Star
        if (corners == 3) return Ability.EMBER_WARD;                   // Triangle
        if (corners == 4) return Ability.IRON_BASTION;                 // Square
        if (windings >= 2.2) return Ability.VOID_STRIKE;               // Tight zigzag = high winding
        if (variance < 0.25 && meanAngleDelta(pts) < 1.0) return Ability.ECLIPSE_WAVE; // Smooth crescent
        if (corners >= 6) return Ability.GRAVITY_WELL;                 // Many corners = spiral
        if (countDirectionChanges(pts) >= 8) return Ability.MANA_ECHO; // Wave pattern
        
        return null;
    }

    private static List<float[]> resample(List<float[]> in, int n) {
        double len = 0;
        for (int i = 1; i < in.size(); i++) len += dist(in.get(i - 1), in.get(i));
        double step = len / (n - 1);
        List<float[]> out = new ArrayList<>();
        if (step <= 0) return out;
        List<float[]> src = new ArrayList<>(in);
        out.add(src.get(0));
        double acc = 0;
        for (int i = 1; i < src.size(); i++) {
            float[] a = src.get(i - 1), b = src.get(i);
            double d = dist(a, b);
            if (acc + d >= step && d > 0) {
                double t = (step - acc) / d;
                float[] q = {(float) (a[0] + t * (b[0] - a[0])), (float) (a[1] + t * (b[1] - a[1]))};
                out.add(q);
                src.add(i, q);
                acc = 0;
            } else acc += d;
        }
        while (out.size() < n) out.add(src.get(src.size() - 1));
        return out;
    }

    private static int countCorners(List<float[]> p, int k, double threshold) {
        int n = p.size();
        boolean[] flag = new boolean[n];
        for (int i = 0; i < n; i++) {
            float[] a = p.get(Math.floorMod(i - k, n)), b = p.get(i), c = p.get((i + k) % n);
            flag[i] = Math.abs(angle(a, b, c)) > threshold;
        }
        int count = 0;
        for (int i = 0; i < n; i++) if (flag[i] && !flag[Math.floorMod(i - 1, n)]) count++;
        if (count == 0 && flag[0]) count = 1;
        return count;
    }

    private static double totalTurning(List<float[]> p) {
        double sum = 0;
        int n = p.size();
        for (int i = 0; i < n; i++) sum += angle(p.get(Math.floorMod(i - 1, n)), p.get(i), p.get((i + 1) % n));
        return sum;
    }

    private static int countDirectionChanges(List<float[]> p) {
        int changes = 0;
        for (int i = 1; i < p.size() - 1; i++) {
            double a = Math.atan2(p.get(i)[1] - p.get(i - 1)[1], p.get(i)[0] - p.get(i - 1)[0]);
            double b = Math.atan2(p.get(i + 1)[1] - p.get(i)[1], p.get(i + 1)[0] - p.get(i)[0]);
            if (Math.abs(a - b) > 0.5) changes++;
        }
        return changes;
    }

    private static double meanAngleDelta(List<float[]> p) {
        double sum = 0;
        for (int i = 1; i < p.size() - 1; i++) sum += Math.abs(angle(p.get(i - 1), p.get(i), p.get(i + 1)));
        return sum / Math.max(1, p.size() - 2);
    }

    private static double angle(float[] a, float[] b, float[] c) {
        double x1 = b[0] - a[0], y1 = b[1] - a[1], x2 = c[0] - b[0], y2 = c[1] - b[1];
        if ((x1 == 0 && y1 == 0) || (x2 == 0 && y2 == 0)) return 0;
        return Math.atan2(x1 * y2 - y1 * x2, x1 * x2 + y1 * y2);
    }

    private static double dist(float[] a, float[] b) { return Math.hypot(a[0] - b[0], a[1] - b[1]); }
}
