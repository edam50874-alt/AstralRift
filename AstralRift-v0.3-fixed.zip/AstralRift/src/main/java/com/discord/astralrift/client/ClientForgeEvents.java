package com.discord.astralrift.client;

import com.discord.astralrift.AstralRift;
import com.discord.astralrift.network.ModNetwork;
import com.discord.astralrift.network.UseAbilityPacket;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AstralRift.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private ClientForgeEvents() {}

    /** Hunger bar deleted from the HUD. */
    @SubscribeEvent
    public static void hideFood(RenderGuiOverlayEvent.Pre e) {
        if (e.getOverlay() == VanillaGuiOverlay.FOOD_LEVEL.type()) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        while (ClientModEvents.ASTRAL_KEY.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new UseAbilityPacket("astral_projection"));
        }
    }
}
