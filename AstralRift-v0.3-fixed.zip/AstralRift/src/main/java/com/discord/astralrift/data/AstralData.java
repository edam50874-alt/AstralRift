package com.discord.astralrift.data;

import com.discord.astralrift.AstralRift;
import com.discord.astralrift.ability.Ability;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

import java.util.EnumSet;
import java.util.Set;

/**
 * All mod state lives under Player.PERSISTED_NBT_TAG so it survives death.
 * canvasResolved = player already drew a valid shape.
 * canvasLocked   = player died before drawing; canvas never returns.
 */
public final class AstralData {
    public static final float BASE_MAX_MANA = 100f;

    private AstralData() {}

    public static CompoundTag root(Player p) {
        CompoundTag pd = p.getPersistentData();
        if (!pd.contains(Player.PERSISTED_NBT_TAG)) pd.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        CompoundTag persisted = pd.getCompound(Player.PERSISTED_NBT_TAG);
        if (!persisted.contains(AstralRift.MODID)) {
            CompoundTag fresh = new CompoundTag();
            fresh.putFloat("mana", BASE_MAX_MANA);
            persisted.put(AstralRift.MODID, fresh);
        }
        return persisted.getCompound(AstralRift.MODID);
    }

    // ---- Canvas lifecycle
    public static boolean canvasAvailable(Player p) {
        CompoundTag d = root(p);
        return !d.getBoolean("canvasResolved") && !d.getBoolean("canvasLocked");
    }
    public static void resolveCanvas(Player p) { root(p).putBoolean("canvasResolved", true); }
    public static void lockCanvas(Player p) { root(p).putBoolean("canvasLocked", true); }

    // ---- Abilities
    public static Set<Ability> abilities(Player p) {
        EnumSet<Ability> set = EnumSet.noneOf(Ability.class);
        for (String s : root(p).getString("abilities").split(",")) {
            Ability a = Ability.byId(s);
            if (a != null) set.add(a);
        }
        return set;
    }
    public static boolean has(Player p, Ability a) { return abilities(p).contains(a); }
    public static void grant(Player p, Ability a) {
        Set<Ability> set = abilities(p);
        set.add(a);
        StringBuilder sb = new StringBuilder();
        for (Ability x : set) { if (sb.length() > 0) sb.append(','); sb.append(x.id); }
        root(p).putString("abilities", sb.toString());
    }

    // ---- Mana
    public static float maxMana(Player p) { return BASE_MAX_MANA + (has(p, Ability.MANA_SURGE) ? 50f : 0f); }
    public static float mana(Player p) { return root(p).getFloat("mana"); }
    public static void setMana(Player p, float v) { root(p).putFloat("mana", Math.max(0, Math.min(maxMana(p), v))); }
    public static boolean trySpend(Player p, float cost) {
        if (p.isCreative()) return true;
        float m = mana(p);
        if (m < cost) return false;
        setMana(p, m - cost);
        return true;
    }
}
