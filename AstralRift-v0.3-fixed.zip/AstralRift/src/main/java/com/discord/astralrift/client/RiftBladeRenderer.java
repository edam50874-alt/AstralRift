package com.discord.astralrift.client;

import com.discord.astralrift.AstralRift;
import com.discord.astralrift.item.RiftBladeItem;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.DefaultedItemGeoModel;
import software.bernie.geckolib.renderer.GeoItemRenderer;

public class RiftBladeRenderer extends GeoItemRenderer<RiftBladeItem> {
    public RiftBladeRenderer() {
        super(new DefaultedItemGeoModel<>(new ResourceLocation(AstralRift.MODID, "rift_blade")));
    }
}
